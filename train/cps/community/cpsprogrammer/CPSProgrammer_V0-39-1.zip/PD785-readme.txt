Due to the slow GUI of the CPS, CPSProgrammer comes with some limitations:
- The GUI of the CPS is very slow (about 10 times slower than CS700!).
- To speed up the CPS a bit, please disable the help view shown a the bottom end of the CPS window.
